import numpy
import json

config = json.load(open(".\\python\\config.json", "r"))
stageLvl = 0

for stage in config["overworld"].values():
    stageLvl += 1
    if len(stage) < 1: continue

    points = set([])

    h,k = 0,0
    r = stage[0]
    precision = stage[1]

    theta = numpy.linspace(0, 2 * numpy.pi, stage[2])
    x = numpy.round(h + r * numpy.cos(theta), precision)
    y = numpy.round(k + r * numpy.sin(theta), precision)

    print(f"Stage {stageLvl} has {len(x)} points")

    for i in range(len(x)):
        points.add((x[i], y[i]))

    commands = ""

    for point in points:
        commands += f"particle dust 1.000 0.000 0.000 2 ~{point[0]} ~0.5 ~{point[1]} 0.2 0.2 0.2 1 5 force\n"

    with open(f"data\\dpc\\functions\\stages\\world_border\\particles\\stage{stageLvl}.mcfunction", "w") as f:
        f.write(commands)
