import json

data = json.loads(open('.\\python\\config.json').read())["overworld"]
pointer = 0

for i in data:
    pointer +=1
    if len(data[i]) <1: continue
    print(f"execute if score .level stage matches {pointer} as @p[distance={data[i][0]}..] run function dpc:stages/world_border/kill")