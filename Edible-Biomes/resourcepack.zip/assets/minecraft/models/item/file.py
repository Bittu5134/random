import json

names = [
    "coral",
    "desert",
    "ice",
    "jungle",
    "lush",
    "mountain",
    "mushroom",
    "plains",
    "tiaga",
]
data1 = {
    "parent": "minecraft:item/handheld_rod",
    "textures": {"layer0": "minecraft:item/warped_fungus_on_a_stick"},
    "overrides": [],
}

data2 = {
    "parent": "minecraft:item/generated",
    "textures": {"layer0": "minecraft:item/string"},
    "overrides": [],
}

index = 1000

for name in names:
    predicate1 = {
        "predicate": {"custom_model_data": index},
        "model": f"item/forks/{name}_fork",
    }
    predicate2 = {
        "predicate": {"custom_model_data": index},
        "model": f"item/forks/{name}_handle",
    }
    index += 1
    data1["overrides"].append(predicate1)
    data2["overrides"].append(predicate2)

with open(
    "assets\\minecraft\\models\\item\\warped_fungus_on_a_stick.json", "w"
) as file:
    json.dump(data1, file, indent=4)

with open(
    "assets\\minecraft\\models\\item\\string.json", "w"
) as file:
    json.dump(data2, file, indent=4)
