names = [
    "coral",
    "desert",
    "ice",
    "jungle",
    "lush",
    "mountain",
    "mushroom",
    "plains",
    "tiaga",
]

index= 1000


for name in names:
    print("give @p warped_fungus_on_a_stick{CustomModelData:"+str(index)+"} 1")
    print("give @p gold_nugget{CustomModelData:"+str(index)+"} 1")
    index += 1




