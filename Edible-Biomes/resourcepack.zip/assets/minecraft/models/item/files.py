names = ["coral", "desert", "ice", "jungle", "lush", "mountain", "mushroom", "plains", "tiaga"]

for name in names:
    with open(f"assets\\minecraft\\models\\item\\forks\\{name}_handle.json", "w") as f:
        f.write("""{
	"credit": "Made with Blockbench",
	"texture_size": [32, 32],
	"textures": {\n""")
        
        f.write(f'''		"0": "item/forks/{name}_handle",
		"particle": "item/forks/{name}_handle"\n''')
            
        f.write("""},
	"elements": [
		{
			"name": "handle",
			"from": [7.5, -7.9, 7.5],
			"to": [8.5, 18.1, 8.5],
			"faces": {
				"north": {"uv": [0, 0, 0.5, 13], "texture": "#0"},
				"east": {"uv": [0.5, 0, 1, 13], "texture": "#0"},
				"south": {"uv": [1, 0, 1.5, 13], "texture": "#0"},
				"west": {"uv": [1.5, 0, 2, 13], "texture": "#0"},
				"up": {"uv": [4.5, 8.5, 4, 8], "texture": "#0"},
				"down": {"uv": [8.5, 4, 8, 4.5], "texture": "#0"}
			}
		},
		{
			"name": "handle_fork_connection",
			"from": [6.5, 18.1, 7.5],
			"to": [9.5, 19.1, 8.5],
			"faces": {
				"north": {"uv": [4.5, 2, 6, 2.5], "texture": "#0"},
				"east": {"uv": [2, 6, 2.5, 6.5], "texture": "#0"},
				"south": {"uv": [4.5, 2.5, 6, 3], "texture": "#0"},
				"west": {"uv": [6, 2, 6.5, 2.5], "texture": "#0"},
				"up": {"uv": [6, 3.5, 4.5, 3], "texture": "#0"},
				"down": {"uv": [6, 3.5, 4.5, 4], "texture": "#0"}
			}
		},
		{
			"name": "fork_center_bottom",
			"from": [7.5, 19.1, 7.5],
			"to": [8.5, 23.1, 8.5],
			"faces": {
				"north": {"uv": [2, 0, 2.5, 2], "texture": "#0"},
				"east": {"uv": [2, 2, 2.5, 4], "texture": "#0"},
				"south": {"uv": [2.5, 0, 3, 2], "texture": "#0"},
				"west": {"uv": [2.5, 2, 3, 4], "texture": "#0"},
				"up": {"uv": [3, 6.5, 2.5, 6], "texture": "#0"},
				"down": {"uv": [6.5, 2.5, 6, 3], "texture": "#0"}
			}
		},
		{
			"name": "fork_left_bottom",
			"from": [9.5, 19.1, 7.5],
			"to": [10.5, 22.1, 8.5],
			"faces": {
				"north": {"uv": [4.5, 4, 5, 5.5], "texture": "#0"},
				"east": {"uv": [5, 0, 5.5, 1.5], "texture": "#0"},
				"south": {"uv": [5, 4, 5.5, 5.5], "texture": "#0"},
				"west": {"uv": [5.5, 0, 6, 1.5], "texture": "#0"},
				"up": {"uv": [3.5, 6.5, 3, 6], "texture": "#0"},
				"down": {"uv": [6.5, 3, 6, 3.5], "texture": "#0"}
			}
		},
		{
			"name": "fork_right_bottom",
			"from": [5.5, 19.1, 7.5],
			"to": [6.5, 22.1, 8.5],
			"faces": {
				"north": {"uv": [5.5, 4, 6, 5.5], "texture": "#0"},
				"east": {"uv": [4.5, 5.5, 5, 7], "texture": "#0"},
				"south": {"uv": [5, 5.5, 5.5, 7], "texture": "#0"},
				"west": {"uv": [5.5, 5.5, 6, 7], "texture": "#0"},
				"up": {"uv": [4, 6.5, 3.5, 6], "texture": "#0"},
				"down": {"uv": [6.5, 3.5, 6, 4], "texture": "#0"}
			}
		},
		{
			"name": "fork_right_top",
			"from": [5.5, 22.1391, 6.69657],
			"to": [6.5, 26.1391, 7.79657],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [6, 24.1391, 7.19657]},
			"faces": {
				"north": {"uv": [3, 0, 3.5, 2], "texture": "#0"},
				"east": {"uv": [3, 2, 3.5, 4], "texture": "#0"},
				"south": {"uv": [3.5, 0, 4, 2], "texture": "#0"},
				"west": {"uv": [3.5, 2, 4, 4], "texture": "#0"},
				"up": {"uv": [4.5, 6.5, 4, 6], "texture": "#0"},
				"down": {"uv": [6.5, 4, 6, 4.5], "texture": "#0"}
			}
		},
		{
			"name": "fork_right_top_connection",
			"from": [5.5, 22.1, 7.5],
			"to": [6.5, 22.5, 8.5],
			"faces": {
				"north": {"uv": [6, 4.5, 6.5, 5], "texture": "#0"},
				"east": {"uv": [6, 5, 6.5, 5.5], "texture": "#0"},
				"south": {"uv": [6, 5.5, 6.5, 6], "texture": "#0"},
				"west": {"uv": [6, 6, 6.5, 6.5], "texture": "#0"},
				"up": {"uv": [7, 0.5, 6.5, 0], "texture": "#0"},
				"down": {"uv": [7, 0.5, 6.5, 1], "texture": "#0"}
			}
		},
		{
			"name": "fork_left_top_connection",
			"from": [9.5, 22.1, 7.5],
			"to": [10.5, 22.5, 8.5],
			"rotation": {"angle": 0, "axis": "y", "origin": [4, 0, 0]},
			"faces": {
				"north": {"uv": [6.5, 1, 7, 1.5], "texture": "#0"},
				"east": {"uv": [6.5, 1.5, 7, 2], "texture": "#0"},
				"south": {"uv": [2, 6.5, 2.5, 7], "texture": "#0"},
				"west": {"uv": [6.5, 2, 7, 2.5], "texture": "#0"},
				"up": {"uv": [3, 7, 2.5, 6.5], "texture": "#0"},
				"down": {"uv": [7, 2.5, 6.5, 3], "texture": "#0"}
			}
		},
		{
			"name": "fork_left_top",
			"from": [9.5, 22.1391, 6.69657],
			"to": [10.5, 26.1391, 7.79657],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [10, 24.1391, 7.19657]},
			"faces": {
				"north": {"uv": [4, 0, 4.5, 2], "texture": "#0"},
				"east": {"uv": [2, 4, 2.5, 6], "texture": "#0"},
				"south": {"uv": [4, 2, 4.5, 4], "texture": "#0"},
				"west": {"uv": [2.5, 4, 3, 6], "texture": "#0"},
				"up": {"uv": [3.5, 7, 3, 6.5], "texture": "#0"},
				"down": {"uv": [7, 3, 6.5, 3.5], "texture": "#0"}
			}
		},
		{
			"name": "fork_center_top_connection",
			"from": [7.5, 23.1, 7.5],
			"to": [8.5, 23.5, 8.5],
			"rotation": {"angle": 0, "axis": "y", "origin": [2, 1, 0]},
			"faces": {
				"north": {"uv": [3.5, 6.5, 4, 7], "texture": "#0"},
				"east": {"uv": [6.5, 3.5, 7, 4], "texture": "#0"},
				"south": {"uv": [4, 6.5, 4.5, 7], "texture": "#0"},
				"west": {"uv": [6.5, 4, 7, 4.5], "texture": "#0"},
				"up": {"uv": [7, 5, 6.5, 4.5], "texture": "#0"},
				"down": {"uv": [7, 5, 6.5, 5.5], "texture": "#0"}
			}
		},
		{
			"name": "fork_center_top",
			"from": [7.5, 23.1391, 6.69657],
			"to": [8.5, 27.1391, 7.79657],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [8, 25.1391, 7.19657]},
			"faces": {
				"north": {"uv": [3, 4, 3.5, 6], "texture": "#0"},
				"east": {"uv": [3.5, 4, 4, 6], "texture": "#0"},
				"south": {"uv": [4, 4, 4.5, 6], "texture": "#0"},
				"west": {"uv": [4.5, 0, 5, 2], "texture": "#0"},
				"up": {"uv": [7, 6, 6.5, 5.5], "texture": "#0"},
				"down": {"uv": [6.5, 6.5, 6, 7], "texture": "#0"}
			}
		},
		{
			"from": [5.5, 25.94479, 5.91968],
			"to": [6.5, 26.14479, 7.01968],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.55, 25.99479, 6.31968]},
			"faces": {
				"north": {"uv": [6.5, 6, 7, 6.5], "texture": "#0"},
				"east": {"uv": [6.5, 6.5, 7, 7], "texture": "#0"},
				"south": {"uv": [7, 0, 7.5, 0.5], "texture": "#0"},
				"west": {"uv": [7, 0.5, 7.5, 1], "texture": "#0"},
				"up": {"uv": [7.5, 1.5, 7, 1], "texture": "#0"},
				"down": {"uv": [7.5, 1.5, 7, 2], "texture": "#0"}
			}
		},
		{
			"from": [7.8, 27.46022, 6.29455],
			"to": [8.2, 27.66022, 7.39455],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.55, 26.01022, 6.29455]},
			"faces": {
				"north": {"uv": [2, 7, 2.5, 7.5], "texture": "#0"},
				"east": {"uv": [7, 2, 7.5, 2.5], "texture": "#0"},
				"south": {"uv": [2.5, 7, 3, 7.5], "texture": "#0"},
				"west": {"uv": [7, 2.5, 7.5, 3], "texture": "#0"},
				"up": {"uv": [3.5, 7.5, 3, 7], "texture": "#0"},
				"down": {"uv": [7.5, 3, 7, 3.5], "texture": "#0"}
			}
		},
		{
			"from": [9.5, 25.86022, 6.29455],
			"to": [10.5, 26.06022, 7.39455],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.65, 25.01022, 6.29455]},
			"faces": {
				"north": {"uv": [3.5, 7, 4, 7.5], "texture": "#0"},
				"east": {"uv": [7, 3.5, 7.5, 4], "texture": "#0"},
				"south": {"uv": [4, 7, 4.5, 7.5], "texture": "#0"},
				"west": {"uv": [7, 4, 7.5, 4.5], "texture": "#0"},
				"up": {"uv": [5, 7.5, 4.5, 7], "texture": "#0"},
				"down": {"uv": [7.5, 4.5, 7, 5], "texture": "#0"}
			}
		},
		{
			"from": [9.6, 26.06022, 6.29455],
			"to": [10.4, 26.26022, 7.39455],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.65, 25.01022, 6.29455]},
			"faces": {
				"north": {"uv": [5, 7, 5.5, 7.5], "texture": "#0"},
				"east": {"uv": [7, 5, 7.5, 5.5], "texture": "#0"},
				"south": {"uv": [5.5, 7, 6, 7.5], "texture": "#0"},
				"west": {"uv": [7, 5.5, 7.5, 6], "texture": "#0"},
				"up": {"uv": [6.5, 7.5, 6, 7], "texture": "#0"},
				"down": {"uv": [7.5, 6, 7, 6.5], "texture": "#0"}
			}
		},
		{
			"from": [9.7, 26.26022, 6.29455],
			"to": [10.3, 26.46022, 7.39455],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.65, 25.01022, 6.29455]},
			"faces": {
				"north": {"uv": [6.5, 7, 7, 7.5], "texture": "#0"},
				"east": {"uv": [7, 6.5, 7.5, 7], "texture": "#0"},
				"south": {"uv": [7, 7, 7.5, 7.5], "texture": "#0"},
				"west": {"uv": [7.5, 0, 8, 0.5], "texture": "#0"},
				"up": {"uv": [8, 1, 7.5, 0.5], "texture": "#0"},
				"down": {"uv": [8, 1, 7.5, 1.5], "texture": "#0"}
			}
		},
		{
			"from": [9.8, 26.46022, 6.29455],
			"to": [10.2, 26.66022, 7.39455],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.65, 25.01022, 6.29455]},
			"faces": {
				"north": {"uv": [7.5, 1.5, 8, 2], "texture": "#0"},
				"east": {"uv": [2, 7.5, 2.5, 8], "texture": "#0"},
				"south": {"uv": [7.5, 2, 8, 2.5], "texture": "#0"},
				"west": {"uv": [2.5, 7.5, 3, 8], "texture": "#0"},
				"up": {"uv": [8, 3, 7.5, 2.5], "texture": "#0"},
				"down": {"uv": [3.5, 7.5, 3, 8], "texture": "#0"}
			}
		},
		{
			"from": [7.7, 27.26022, 6.29455],
			"to": [8.3, 27.46022, 7.39455],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.55, 26.01022, 6.29455]},
			"faces": {
				"north": {"uv": [7.5, 3, 8, 3.5], "texture": "#0"},
				"east": {"uv": [3.5, 7.5, 4, 8], "texture": "#0"},
				"south": {"uv": [7.5, 3.5, 8, 4], "texture": "#0"},
				"west": {"uv": [4, 7.5, 4.5, 8], "texture": "#0"},
				"up": {"uv": [8, 4.5, 7.5, 4], "texture": "#0"},
				"down": {"uv": [5, 7.5, 4.5, 8], "texture": "#0"}
			}
		},
		{
			"from": [7.6, 27.06022, 6.29455],
			"to": [8.4, 27.26022, 7.39455],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.55, 26.01022, 6.29455]},
			"faces": {
				"north": {"uv": [5, 1.5, 5.5, 2], "texture": "#0"},
				"east": {"uv": [5.5, 1.5, 6, 2], "texture": "#0"},
				"south": {"uv": [6, 0, 6.5, 0.5], "texture": "#0"},
				"west": {"uv": [6, 0.5, 6.5, 1], "texture": "#0"},
				"up": {"uv": [6.5, 1.5, 6, 1], "texture": "#0"},
				"down": {"uv": [6.5, 1.5, 6, 2], "texture": "#0"}
			}
		},
		{
			"from": [7.5, 26.86022, 6.29455],
			"to": [8.5, 27.06022, 7.39455],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.55, 26.01022, 6.29455]},
			"faces": {
				"north": {"uv": [7.5, 4.5, 8, 5], "texture": "#0"},
				"east": {"uv": [5, 7.5, 5.5, 8], "texture": "#0"},
				"south": {"uv": [7.5, 5, 8, 5.5], "texture": "#0"},
				"west": {"uv": [5.5, 7.5, 6, 8], "texture": "#0"},
				"up": {"uv": [8, 6, 7.5, 5.5], "texture": "#0"},
				"down": {"uv": [6.5, 7.5, 6, 8], "texture": "#0"}
			}
		},
		{
			"from": [5.6, 26.14479, 5.91968],
			"to": [6.4, 26.34479, 7.01968],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.55, 25.99479, 6.31968]},
			"faces": {
				"north": {"uv": [7.5, 6, 8, 6.5], "texture": "#0"},
				"east": {"uv": [6.5, 7.5, 7, 8], "texture": "#0"},
				"south": {"uv": [7.5, 6.5, 8, 7], "texture": "#0"},
				"west": {"uv": [7, 7.5, 7.5, 8], "texture": "#0"},
				"up": {"uv": [8, 7.5, 7.5, 7], "texture": "#0"},
				"down": {"uv": [8, 7.5, 7.5, 8], "texture": "#0"}
			}
		},
		{
			"from": [5.7, 26.34479, 5.91968],
			"to": [6.3, 26.54479, 7.01968],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.55, 25.99479, 6.31968]},
			"faces": {
				"north": {"uv": [8, 0, 8.5, 0.5], "texture": "#0"},
				"east": {"uv": [8, 0.5, 8.5, 1], "texture": "#0"},
				"south": {"uv": [8, 1, 8.5, 1.5], "texture": "#0"},
				"west": {"uv": [8, 1.5, 8.5, 2], "texture": "#0"},
				"up": {"uv": [2.5, 8.5, 2, 8], "texture": "#0"},
				"down": {"uv": [8.5, 2, 8, 2.5], "texture": "#0"}
			}
		},
		{
			"from": [5.8, 26.54479, 5.91968],
			"to": [6.2, 26.74479, 7.01968],
			"rotation": {"angle": -22.5, "axis": "x", "origin": [5.55, 25.99479, 6.31968]},
			"faces": {
				"north": {"uv": [2.5, 8, 3, 8.5], "texture": "#0"},
				"east": {"uv": [8, 2.5, 8.5, 3], "texture": "#0"},
				"south": {"uv": [3, 8, 3.5, 8.5], "texture": "#0"},
				"west": {"uv": [8, 3, 8.5, 3.5], "texture": "#0"},
				"up": {"uv": [4, 8.5, 3.5, 8], "texture": "#0"},
				"down": {"uv": [8.5, 3.5, 8, 4], "texture": "#0"}
			}
		}
	],
	"display": {
		"thirdperson_righthand": {
			"rotation": [-39, -180, 0],
			"translation": [0, 0, 1.25],
			"scale": [0.8, 0.8, 0.8]
		},
		"thirdperson_lefthand": {
			"rotation": [-39, -180, 0],
			"translation": [0, 0, 1.25],
			"scale": [0.8, 0.8, 0.8]
		},
		"firstperson_righthand": {
			"rotation": [-63, -178, 0],
			"translation": [0.75, 0, 0]
		},
		"firstperson_lefthand": {
			"rotation": [-63, -178, 0],
			"translation": [3.75, 0, 1.25]
		},
		"ground": {
			"rotation": [85, 0, 0],
			"scale": [0.75, 0.75, 0.75]
		},
		"gui": {
			"rotation": [0, 180, 44],
			"translation": [-1.25, -0.75, 0],
			"scale": [1, 0.68, 1]
		},
		"fixed": {
			"rotation": [0, 0, 43],
			"translation": [0, 0, -0.75]
		}
	}
}""")