import random
for x in range(5):
    for y in range(5):
        for z in range(5):
            # print([x-2,y-2,z-2])
            print(f"execute if block ~{x-2} ~{y-2} ~{z-2} #taglib:overworld_natural run setblock ~{x-2} ~{y-2} ~{z-2} {random.choice(["minecraft:brown_mushroom_block","minecraft:red_mushroom_block"])}")
